// An implementation of a Training Record as an ArrayList
package com.stir.cscu9t4practical1;


import java.util.*;


public class TrainingRecord {
    private List<Entry> tr;
    
    public TrainingRecord() {
        tr = new ArrayList<Entry>();
    } //constructor
    
    // add a record to the list
   public void addEntry(Entry e){
       tr.add(e);    
   } // addClass



    public String lookupEntry (int d, int m, int y)
    {
        ListIterator<Entry> iter = tr.listIterator();
        String result = "No entries found";
        while (iter.hasNext())
        {
            Entry current = iter.next();
            if (current.getDay()==d && current.getMonth()==m && current.getYear()==y)
                result = current.getEntry();
        }
        return result;
    } // lookupEntry

    /*
    findAllByDate is similar to lookupEntry however it outputs all atheltes on a given date
     */
    public String findAllByDate (int d, int m, int y) {
        ListIterator<Entry> iter = tr.listIterator();
        StringBuilder result = new StringBuilder(); //builds the string together

        while (iter.hasNext()) {
            Entry current = iter.next();
            if (current.getDay()==d && current.getMonth()==m && current.getYear()==y)
            {
                result.append(current.getEntry()); //appends the entries to the result
            }
        }
        if(result.length() == 0) //checks there are entries that have been stored on that date
        {
            return "No Entries with that date";
        }

        return result.toString(); //returns the entries on that date
    }

    public boolean findAthlete (String n, int d, int m, int y)
    {
        ListIterator<Entry> iter = tr.listIterator();
        while(iter.hasNext())
        {
            Entry current = iter.next();
            if(current.getDay()==d && current.getMonth()==m && current.getYear()==y && current.getName().equals(n))
                return true;
        }
        return false;
    }

    public String findRunnerAll (String n) {
        String message = "";
        ListIterator<Entry> iter = tr.listIterator();
        while (iter.hasNext()) {
            Entry current = iter.next();
            if (current.getName().equals(n))
                message = message + current.getEntry();
        }
        if (message.equals(""))
            message = "Could not find any runs, please ensure the name is spelled correctly";
        return message;
    }

    // removes the entry of a given date and name
    public String removeEntry(String n, int d, int m, int y) {
        ListIterator<Entry> iter = tr.listIterator();
        while (iter.hasNext()) {
            Entry current = iter.next();
            if (current.getDay() == d && current.getMonth() == m && current.getYear() == y && current.getName().equals(n)) {
                tr.remove(current); //removes the selected entry
                return "Record deleted";
            }

        }
        return "Record not deleted or not found";
    }



   // Count the number of entries
   public int getNumberOfEntries(){
       return tr.size();
   }
   // Clear all entries
   public void clearAllEntries(){
       tr.clear();
   }

   
} // TrainingRecord