package com.stir.cscu9t4practical1;

public class SwimEntry extends Entry{
    protected String w, activity;

    public SwimEntry(String n, int d, int m, int y, int h, int min, int s, float dist, String where, String activity)
    {
        super(n,d,m,y,h,min,s,dist);
        this.w = where;
        this.activity = activity;
    }

    public String getWhere()
    {
        return w;
    } //gets location

    public String getActivity()
    {
        return activity;
    } //gets activity

    @Override //overrides the original entry class
    public String getEntry () {
        String result = getName()+" swam " + getDistance() + " km " + getWhere() + " in "
                +getHour()+":"+getMin()+":"+ getSec() + " on "
                +getDay()+"/"+getMonth()+"/"+getYear()+"\n";
        return result;
    }
}
